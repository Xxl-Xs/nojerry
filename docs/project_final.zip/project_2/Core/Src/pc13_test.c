#include "pc13_test.h"

/* 一些板子（如 BluePill）PC13 上的 LED 为“低电平点亮”
 * 如果你的板子是“高电平点亮”，把下方这个宏改为 1
 */
#ifndef PC13_LED_ACTIVE_HIGH
#define PC13_LED_ACTIVE_HIGH   0
#endif

void PC13_Test_Init(void)
{
    /* 1) 打开 GPIOC 时钟 */
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* 2) 配置 PC13 为推挽输出（2MHz 足够） */
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin   = GPIO_PIN_13;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* 3) 置为“灭灯” */
#if PC13_LED_ACTIVE_HIGH
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
#else
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
#endif
}

void PC13_Toggle(void)
{
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
}

void PC13_Blink_Loop(uint32_t period_ms)
{
    while (1) {
        PC13_Toggle();
        HAL_Delay(period_ms);
    }
}
