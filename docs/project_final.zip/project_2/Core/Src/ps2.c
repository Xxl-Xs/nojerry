/*************************************************************************************************
 * @brief   通过 SPI 读取 PS2 手柄，并对原始数据做解析与缓存
 * @version 2.0
 * @date    2021.12.24
 * @param   none
 * @retval  none
 * @author  ysl
 *************************************************************************************************/

#include "PS2.h"
#include "spi.h"

/* 发送到 PS2 的 3 字节基础命令序列：
 *  0x01：起始命令（请求进入交互）
 *  0x42：读数据命令（手柄返回当前状态）
 *  0x00：占位/继续时钟，用于继续时序产生并取回后续字节
 */
uint8_t cmd[3] = {0x01,0x42,0x00};

/* PS2 每帧共取回 9 个字节，这里作为接收缓存：
 *  PS2data[0]：响应（通常固定）
 *  PS2data[1]：模式/状态（红灯/绿灯等）
 *  PS2data[2]：按键/数据起始标记
 *  PS2data[3]：按键组1（每一位代表一个按键，低电平表示按下）
 *  PS2data[4]：按键组2
 *  PS2data[5]：LX（左摇杆 X）
 *  PS2data[6]：LY（左摇杆 Y）
 *  PS2data[7]：RX（右摇杆 X）
 *  PS2data[8]：RY（右摇杆 Y）
 */
uint8_t PS2data[9] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

/* 将 0~255 的摇杆原始值线性映射到 0~1000，默认居中 500 */
uint16_t XY[4] = {500,500,500,500};      // 顺序：LX, LY, RX, RY

/* 循环用通用变量 */
uint8_t i;

/* 每个按键的当前状态缓存（16 个按键），1 表示按下，0 表示松开。
 * 注意：PS2 原始协议里按下为低电平，这里在后续处理里做了“翻转”成更直观的高为按下。
 */
uint8_t All_But[16] = {
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

/**
 * @brief   微秒级延时（基于 HAL SysTick），用于 SPI 每字节之间留出时序空隙
 * @param   udelay  需要延时的微秒数
 */
void delay_us(uint32_t udelay)
{
  uint32_t startval,tickn,delays,wait;

  startval = SysTick->VAL;
  tickn = HAL_GetTick();
  /* SysTick 每 1ms 计数 72000 次（72MHz），这里用 72 * 微秒 得到期望 tick 数 */
  delays = udelay * 72;

  if(delays > startval)
  {
    /* 等到下一个 ms 滴答发生，再等待补足差值 */
    while(HAL_GetTick() == tickn) { }
    wait = 72000 + startval - delays;
    while(wait < SysTick->VAL) { }
  }
  else
  {
    /* 仍在当前 ms 内，直接等到计数器回退到目标值 */
    wait = startval - delays;
    while(wait < SysTick->VAL && HAL_GetTick() == tickn) { }
  }
}

/**
 * @brief   通过 SPI 完整读取一次 PS2 手柄的 9 字节数据帧
 *          时序：拉低 CS -> 依次发送 0x01、0x42、0x00，并持续发 0x00 取回剩余数据 -> 拉高 CS
 */
void PS2_Get(void)
{
  short i = 0;

  /* 片选拉低，开始一次通讯 */
  HAL_GPIO_WritePin(CSS_GPIO_Port,CSS_Pin,GPIO_PIN_RESET);

  /* 依次发送/接收，期间加入 10us 的字节间延时以保证时序稳定 */
  HAL_SPI_TransmitReceive(&hspi1,&cmd[0],&PS2data[0],1,0xffff); // 发送 0x01，握手/起始
  delay_us(10);
  HAL_SPI_TransmitReceive(&hspi1,&cmd[1],&PS2data[1],1,0xffff); // 发送 0x42，进入“读当前状态”
  delay_us(10);
  HAL_SPI_TransmitReceive(&hspi1,&cmd[2],&PS2data[2],1,0xffff); // 发送 0x00，占位并取回第 3 字节（ID/模式）
  delay_us(10);

  /* 继续发 0x00，拿回后续 6 个字节（按键 + 摇杆） */
  for(i = 3;i < 9;i++)
  {
    HAL_SPI_TransmitReceive(&hspi1,&cmd[2],&PS2data[i],1,0xffff);
    delay_us(10);
  }

  /* 通讯结束，片选拉高 */
  HAL_GPIO_WritePin(CSS_GPIO_Port,CSS_Pin,GPIO_PIN_SET);
}

/**
 * @brief   上层一次性完成：采样 -> 解析摇杆 -> 解析按键 -> 清空缓存
 *          调用该函数即可在 XY[] 与 All_But[] 中得到新鲜的数据
 */
void GetData(void)
{
  PS2_Get();      // 抓取一帧原始数据
  GetXY();        // 将摇杆 0~255 映射到 0~1000 并做“居中死区”处理
  All_Button();   // 解析 16 个按键状态，转成“按下=1，松开=0”
  CLear_Date();   // 清理缓冲区，为下一次采样做准备
}

/**
 * @brief   将 PS2data[5..8] 的摇杆原始 0~255 值，线性映射到 0~1000
 *          并把 497~503 之间的小波动直接归为 500（中心死区，抗抖）
 */
void GetXY(void)
{
  int i;
  for(i = 5;i < 9;i++)
  {
    PS2data[i] =(int) PS2data[i];
    XY[i-5] = (PS2data[i]* 1000) / 255;         // 线性映射到 0~1000
    if(XY[i-5] <503 && XY[i-5] > 497)  XY[i-5] = 500;   // 中心死区
  }
}

/**
 * @brief   清空 9 字节接收缓存，为下一次采样做准备
 *          其中数据位 [3],[4]（两组按键字节）复位为 0xFF（协议里“未按”为高）
 *          其他字节清零
 */
void CLear_Date(void)
{
  for(i = 0;i<9;i++)
  {
    if(i == 3 || i == 4) PS2data[i] = 0xff;
    else PS2data[i] = 0x00;
  }
}

/**
 * @brief   解析两字节按键状态（PS2data[3], PS2data[4]），拆成 16 个独立按键并做逻辑翻转：
 *          - 协议里：按下=0，未按=1
 *          - 本地缓存：按下=1，未按=0（更直观）
 *          位序说明：先取 PS2data[3] 的 bit7~bit0，再取 PS2data[4] 的 bit7~bit0
 *                    依次存入 All_But[0..15]
 */
void All_Button(void)
{
  uint8_t loc = 1;
  uint8_t set = 0;
  uint8_t but = PS2data[3];

  /* 读取第一个按键字节（PS2data[3]），高位到低位依次取出 */
  for(loc = 8;loc > 0;loc--)
  {
    loc -= 1;
    All_But[set] = (PS2data[3]&(1<<loc))>>loc;
    loc += 1;
    set++;
  }

  /* 读取第二个按键字节（PS2data[4]），高位到低位依次取出 */
  for(loc = 8;loc > 0;loc--)
  {
    loc -= 1;
    All_But[set] = (PS2data[4]&(1<<loc))>>loc;
    loc += 1;
    set++;
  }

  /* 按键逻辑翻转：协议里 0=按下，这里统一换成 1=按下，0=松开 */
  for(set = 0;set < 16;set++)
  {
    if(All_But[set] == 1)  All_But[set] = 0;
    else  All_But[set] = 1;
  }
}
