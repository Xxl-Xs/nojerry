#include "main.h"
#include "motor.h"

// 初始化函数
void Motor_Init(void)
{
  /* 初始化所有电机控制引脚为低电平 */
  HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON1_GPIO_Port, ON1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON2_GPIO_Port, ON2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON3_GPIO_Port, ON3_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON4_GPIO_Port, ON4_Pin, GPIO_PIN_RESET);

  /* 启动 PWM 通道，用于电机速度控制 */
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
}

// 停止所有电机
void Motor_Stop(void)
{
  HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON1_GPIO_Port, ON1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON2_GPIO_Port, ON2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON3_GPIO_Port, ON3_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ON4_GPIO_Port, ON4_Pin, GPIO_PIN_RESET);
}

// 前进
void Motor_Forward(void)
{
  HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, GPIO_PIN_RESET);
}

// 后退
void Motor_Backward(void)
{
  HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, GPIO_PIN_SET);
}

// 左转
void Motor_Left(void)
{
  HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, GPIO_PIN_SET);
}

// 右转
void Motor_Right(void)
{
  HAL_GPIO_WritePin(IN1_GPIO_Port, IN1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(IN2_GPIO_Port, IN2_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(IN3_GPIO_Port, IN3_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(IN4_GPIO_Port, IN4_Pin, GPIO_PIN_RESET);
}

// 速度设置函数（通过PWM占空比控制）
void Motor_SetSpeed(uint16_t duty1, uint16_t duty2)
{
  /* 限制PWM占空比范围 */
  if (duty1 > 1000) duty1 = 1000;
  if (duty2 > 1000) duty2 = 1000;

  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, duty1);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, duty2);
}
