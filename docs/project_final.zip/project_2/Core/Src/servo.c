#include "servo.h"
#include "tim.h"  // 提供 htim2

/* 这里绑定到你已配置好的 TIM2_CH1 / PA0 */
#define SERVO_HTIM      htim2
#define SERVO_CHANNEL   TIM_CHANNEL_1

/* 20ms 周期内，把 us -> CCR。ARR = 周期计数-1 */
static inline uint16_t us_to_ccr(uint16_t us)
{
    uint32_t arr_plus1 = (uint32_t)__HAL_TIM_GET_AUTORELOAD(&SERVO_HTIM) + 1u; // 例如 2000
    /* CCR = us / 20000 * (ARR+1)  —— 与 PSC 无关，稳妥 */
    uint32_t ccr = (arr_plus1 * us) / 20000u;
    if (ccr > arr_plus1 - 1u) ccr = arr_plus1 - 1u;
    return (uint16_t)ccr;
}

void Servo_Init(void)
{
    /* 启动 PWM */
    HAL_TIM_PWM_Start(&SERVO_HTIM, SERVO_CHANNEL);

    /* 输出居中脉冲，防止上电乱跳 */
    Servo_WriteUS(SERVO_MID_US);
}

void Servo_DeInit(void)
{
    /* 置 0（可选），然后停 PWM */
    __HAL_TIM_SET_COMPARE(&SERVO_HTIM, SERVO_CHANNEL, 0);
    HAL_TIM_PWM_Stop(&SERVO_HTIM, SERVO_CHANNEL);
}

void Servo_WriteUS(uint16_t us)
{
    if (us < SERVO_MIN_US) us = SERVO_MIN_US;
    if (us > SERVO_MAX_US) us = SERVO_MAX_US;
    __HAL_TIM_SET_COMPARE(&SERVO_HTIM, SERVO_CHANNEL, us_to_ccr(us));
}

void Servo_WriteDeg(float deg)
{
    if (deg < 0.0f)   deg = 0.0f;
    if (deg > 180.0f) deg = 180.0f;

    float span = (float)(SERVO_MAX_US - SERVO_MIN_US);
    uint16_t us = (uint16_t)(SERVO_MIN_US + (deg / 180.0f) * span + 0.5f);
    Servo_WriteUS(us);
}
void Servo_WriteSpeed(int8_t speed_percent)
{
    if (speed_percent > 100)  speed_percent = 100;
    if (speed_percent < -100) speed_percent = -100;

    int32_t mid  = SERVO_MID_US;                          // 一般 1500
    int32_t span = (SERVO_MAX_US - SERVO_MIN_US) / 2;     // 正反两侧可用范围

    // 线性映射到脉宽：speed=-100 -> mid - span；speed=+100 -> mid + span
    int32_t us = mid + (span * speed_percent) / 100;

    // 可选：扩大/缩小灵敏度，比如只用 80% 范围避免冲击
    // us = mid + (int32_t)((span * 0.8f) * speed_percent / 100);

    Servo_WriteUS((uint16_t)us);   // 复用你已有的函数
}

void Servo_WriteSpeed01(float x)
{
    if (x > 1.0f)  x = 1.0f;
    if (x < -1.0f) x = -1.0f;

    float mid  = (float)SERVO_MID_US;                     // 一般 1500
    float span = (float)(SERVO_MAX_US - SERVO_MIN_US) * 0.5f;

    uint16_t us = (uint16_t)(mid + x * span + 0.5f);
    Servo_WriteUS(us);
}
void Servo_Write01(float x)
{
    if (x < 0.0f) x = 0.0f;
    if (x > 1.0f) x = 1.0f;

    float span = (float)(SERVO_MAX_US - SERVO_MIN_US);
    uint16_t us = (uint16_t)(SERVO_MIN_US + x * span + 0.5f);
    Servo_WriteUS(us);
}
