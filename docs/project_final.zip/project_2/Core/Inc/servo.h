#ifndef __SERVO_H__
#define __SERVO_H__

#include "stm32f1xx_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ====== 可按舵机实际行程微调 ======
 * 常见：1000~2000us 或 500~2500us
 */
#ifndef SERVO_MIN_US
#define SERVO_MIN_US   500u   // 最小脉宽，约 0°
#endif
#ifndef SERVO_MAX_US
#define SERVO_MAX_US  2500u   // 最大脉宽，约 180°
#endif
#ifndef SERVO_MID_US
#define SERVO_MID_US  ((SERVO_MIN_US + SERVO_MAX_US) / 2)  // 居中
#endif

/* 初始化并输出居中脉冲（启动 PWM） */
void Servo_Init(void);

/* 关闭 PWM 输出（让输出脚保持低/上一态，不给脉冲） */
void Servo_DeInit(void);

/* 以“微秒”写入脉宽（自动夹紧到 MIN~MAX） */
void Servo_WriteUS(uint16_t us);

/* 以“角度”写入（0~180，超界将夹紧） */
void Servo_WriteDeg(float deg);

/* 以“归一化”写入（0.0~1.0 映射 MIN~MAX） */
void Servo_Write01(float x);
void Servo_WriteSpeed(int8_t speed_percent);
void Servo_WriteSpeed01(float x);
#ifdef __cplusplus
}
#endif
#endif /* __SERVO_H__ */
