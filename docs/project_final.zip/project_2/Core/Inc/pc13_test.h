#ifndef __PC13_TEST_H__
#define __PC13_TEST_H__

#include "stm32f1xx_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 初始化 PC13（推挽输出） */
void PC13_Test_Init(void);

/* 让 PC13 以固定周期闪烁（阻塞演示） */
void PC13_Blink_Loop(uint32_t period_ms);

/* 单次翻转（当你在自己的循环里调用） */
void PC13_Toggle(void);

#ifdef __cplusplus
}
#endif
#endif /* __PC13_TEST_H__ */
