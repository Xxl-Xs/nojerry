#ifndef MOTOR_H
#define MOTOR_H

#include "main.h"
#include "tim.h"
#include "gpio.h"

void Motor_Init(void);
void Motor_Stop(void);
void Motor_Forward(void);
void Motor_Backward(void);
void Motor_Left(void);
void Motor_Right(void);
void Motor_LeftShift(void);
void Motor_RightShift(void);
void Motor_SetSpeed(uint16_t duty1, uint16_t duty2);

// ... 文件内容 ...
#endif /* MOTOR_H */
