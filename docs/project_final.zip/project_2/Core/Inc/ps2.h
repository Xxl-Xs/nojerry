#include "main.h"

#define CSS_GPIO_Port   GPIOA
#define CSS_Pin         GPIO_PIN_4

#define PSS_Lx 2                
#define PSS_Ly 3
#define PSS_Rx 0
#define PSS_Ry 1


#define PSB_Left        0
#define PSB_Down        1
#define PSB_Right       2
#define PSB_Up          3
#define PSB_Start       4
#define PSB_Select      7
#define PSB_Square      8
#define PSB_Cross       9
#define PSB_Circle      10
#define PSB_Triangle    11
#define PSB_R1          12
#define PSB_L1          13
#define PSB_R2          14
#define PSB_L2          15


void PS2_Get(void);  
void delay_us(uint32_t udelay); 
void GetData(void);  
void GetXY(void); 
void CLear_Date(void);
void All_Button(void);